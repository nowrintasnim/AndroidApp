
package com.example.nabila.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ShareActionProvider;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    String stn;
     DbHelper helper;

    get_P_id p;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        preferences= PreferenceManager.getDefaultSharedPreferences(MainActivity.this);

        editor = preferences.edit();

        String login=preferences.getString("login","");
        if(login.equalsIgnoreCase("1"))
        {
            Intent intent=new Intent(MainActivity.this,home.class);
            String email=preferences.getString("email","");
            String name=preferences.getString("name","");
            String id=preferences.getString("id","");

            intent.putExtra("pid", Integer.parseInt(id));
            intent.putExtra("e", email );
            intent.putExtra("n", name);

            startActivity(intent);
        }


        TextView regLink = (TextView)findViewById(R.id.createText);

        assert regLink != null;
        regLink.setOnClickListener(new View.OnClickListener(){

            public  void onClick(View v)
            {
                Intent regIntent = new Intent(MainActivity.this, sighnup.class);
                MainActivity.this.startActivity(regIntent);
            }
        });

        helper = new DbHelper(this);

    }
    protected  void onButtonClick(View view)
    {
        EditText loginText  = (EditText)findViewById(R.id.loginEmail);
        EditText passText  = (EditText)findViewById(R.id.passText);
        stn = loginText.getText().toString();
        String pass = passText.getText().toString();
        p = new get_P_id();
        if(helper.searchPass(stn,pass, p))
        {

            Intent i = new Intent(MainActivity.this, home.class);

            i.putExtra("pid", p.getPid());
            i.putExtra("e", stn.toString() );
            i.putExtra("n", p.getName());

            editor.putString("login","1");
            editor.putString("email",stn);
            editor.putString("name",p.getName());
            editor.putString("id",Integer.toString(p.getPid()));

            editor.commit();

            MainActivity.this.startActivity(i);
            finish();
        }
        else
        {
            Toast ts = Toast.makeText(MainActivity.this, "Password or email does not match", Toast.LENGTH_SHORT);
            ts.show();
        }

    }


  /*  public boolean onKeyDown(int keycode, KeyEvent event) {
        if (keycode == KeyEvent.KEYCODE_BACK) {
             moveTaskToBack(false);
            String login=preferences.getString("login","");
            if(login.equalsIgnoreCase("0"))
            {
                Intent i=new Intent(MainActivity.this,MainActivity.class);
                startActivity(i);
            }

            finish();
        }

        //return super.onKeyDown(keycode, event);
    }*/
    @Override
    public void onBackPressed() {
        Intent i = getIntent();
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        MainActivity.this.finish();

    }

/*    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }*/
}
