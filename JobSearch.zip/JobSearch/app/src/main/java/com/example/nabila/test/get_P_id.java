package com.example.nabila.test;

/**
 * Created by Nabila on 12/17/2016.
 */
public class get_P_id {

    int pid;
    String name;

    public void setPid(int pid) {
        this.pid = pid;
    }
    public int getPid()
    {
        return  this.pid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
