package com.example.nabila.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class showjob extends AppCompatActivity {

    ArrayAdapter<String> a;
    ListView lp;
    DbHelper h;
    SQLiteDatabase db;
    ListView joblistView;
    int pid;
    Spinner sp ;
    ArrayAdapter<String> adaptor;

    JobListAdaptor jobAdaptor;
    String [] ar= {"Select Category","Electrician","Plumbiing","Catering", "House Staff", "Sales", "Volunteer","Others"};
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.showjob);

        preferences= PreferenceManager.getDefaultSharedPreferences(showjob.this);
        editor=preferences.edit();

        sp =  (Spinner) findViewById(R.id.sp_search);
        adaptor = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ar);
        adaptor.setDropDownViewResource(android.R.layout.simple_selectable_list_item);
        sp.setAdapter(adaptor);
//        jobDataProviders=new ArrayList<JobDataProvider>();

        h =  new DbHelper(this);
        joblistView = (ListView) findViewById(R.id.jobList);
        jobAdaptor = new JobListAdaptor(getApplicationContext(),R.layout.gridrow);

        Intent i = getIntent();
        int pp = i.getIntExtra("pid",-1);
        pid = pp;

        db = h.getReadableDatabase();
        Cursor c = h.getJobForList(db);
        //Log.i("nabila", c.getString(1));
        if(c.moveToFirst())
        {
            do {

                String s1;
                int id,grnt;
                id =c.getInt(0);
                s1=c.getString(1);
                grnt=c.getInt(7);
                int provider_id = c.getInt(8);
                if(provider_id != pid)
                {
                    JobDataProvider ob =  new JobDataProvider();
                    ob.setJobname(s1);
                    ob.setAddress(c.getString(2));
                    ob.setDate(c.getString(3));
                    ob.setTime(c.getString(4));
                    ob.setCategory(c.getString(5));
                    ob.setPayment(c.getString(6));
                    ob.setJobId(c.getInt(0));

                    ob.setEmp_id(c.getInt(8));
                    if(c.getInt(7) == 1)
                        ob.setGrant(true);
                    else ob.setGrant(false);
                  //  Log.i("nabila", "job grant in showjob "+ob.getGrant());
                    jobAdaptor.add(ob);
                }

            }while (c.moveToNext());
        }
        c.close();

        joblistView.setAdapter(jobAdaptor);

        joblistView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // When clicked, show a toast with the TextView text
                String login=preferences.getString("login","");
                if(login.equalsIgnoreCase("0"))
                {
                    Intent i = new Intent(showjob.this,MainActivity.class );
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i); finish();
                    Toast.makeText(showjob.this, "You are not logged in!", Toast.LENGTH_SHORT).show();
                    return;
                }
                JobDataProvider ob = (JobDataProvider) parent.getItemAtPosition(position);
             //   if(ob.getGrant() == false)
              //  {
                    Intent a = new Intent(showjob.this, job_details.class);
                    a.putExtra("jobname",ob.getJobname());
                    a.putExtra("date", ob.getDate());
                    a.putExtra("time", ob.getTime());
                    a.putExtra("cat", ob.getCategory());
                    a.putExtra("pay", ob.getPayment());
                    a.putExtra("add", ob.getAddress());
                    a.putExtra("jobid",ob.getJobidId());
                    // Log.i("nabila", "job id in showjob "+ob.getJobidId());
                    a.putExtra("empid",ob.getEmp_id());
                    a.putExtra("grant", ob.getGrant());
                Log.i("nabila", "job grant in"+ob.getGrant());

                a.putExtra("pid",pid);
                    showjob.this.startActivity(a);
                }
              //  else
                //Toast.makeText(showjob.this, "Already granted applicant for this job", Toast.LENGTH_SHORT).show();
            //}
        });


    }

    public  void search(View view)
    {
        String login=preferences.getString("login","");
        if(login.equalsIgnoreCase("0"))
        {
            Intent i = new Intent(showjob.this,MainActivity.class );
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i); finish();
            Toast.makeText(showjob.this, "You are not logged in!", Toast.LENGTH_SHORT).show();
            return;
        }
        if(sp.getSelectedItemPosition()>0)
        {
            db = h.getReadableDatabase();
            Cursor c = h.getJobForList(db);
            String s = sp.getSelectedItem().toString();

            Boolean b = false;

            JobListAdaptor job=new JobListAdaptor(getApplicationContext(),R.layout.gridrow);


            int i=0;
            if(c.moveToFirst())
            {
                do {

                    int provider_id = c.getInt(8);

                    if(provider_id != pid && s.equals( c.getString(5)))
                    {
                        Log.i("nabila", s + " "+ c.getString(5));
                        JobDataProvider ob =  new JobDataProvider();
                        ob.setJobname(c.getString(1));
                        ob.setAddress(c.getString(2));
                        ob.setDate(c.getString(3));
                        ob.setTime(c.getString(4));
                        ob.setCategory(c.getString(5));
                        ob.setPayment(c.getString(6));
                        ob.setJobId(c.getInt(0));
                           Log.i("nabila", "job name in showjob "+ob.jobname);
                        ob.setEmp_id(c.getInt(8));
                        if(c.getInt(7) == 1)
                            ob.setGrant(true);
                        else ob.setGrant(false);
                        b = true;

                        job.add(ob);
                        Log.i("nur", "job name in showjob "+ob.jobname);
                    }

                }while (c.moveToNext());
            }
            c.close();
            joblistView.setAdapter(job);

            if(b == false) Toast.makeText(this, "No job of this category !",Toast.LENGTH_SHORT).show();
            sp.setSelection(0);

        }
        else {
            Toast.makeText(showjob.this, "Select Category First", Toast.LENGTH_SHORT).show();
            return;
        }
    }
    public void logout(View view)
    {
      //  session.logoutUser();
       // finish();
        editor.putString("login","0");
        editor.commit();
        Intent intent=new Intent(showjob.this,MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

/*    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }*/
}
