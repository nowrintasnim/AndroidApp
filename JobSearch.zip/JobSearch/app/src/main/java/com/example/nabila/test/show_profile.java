package com.example.nabila.test;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import  android.view.View.OnClickListener;
import android.widget.Toast;

public class show_profile extends AppCompatActivity {


    String[] profileArray = new String[7];
    String[] mobileArray = {"Android","IPhone","WindowsMobile","Blackberry",
            "WebOS","Ubuntu","Windows7","Max OS X", "WebOS","Ubuntu","Windows7","Max OS X", "WebOS","Ubuntu","Windows7","Max OS X"};

    ArrayAdapter<String> a;
    ListView lp;
    DbHelper h;
    SQLiteDatabase db;
    int pid;
    String em,ppic = "";
    ImageView imageView;
    Point p;
    EditText expText;
    EditText adText;
    EditText passText;
    EditText phoneText;
    SharedPreferences sharedPreferences;

    private final int SELECT_PHOTO = 1;

    SharedPreferences.Editor editor;
     PopupWindow popup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_profile);
        h= new DbHelper(this);
        db = h.getReadableDatabase();

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(show_profile.this);
        editor=sharedPreferences.edit();

        lp = (ListView)findViewById(R.id.profileView);
        imageView = (ImageView)findViewById(R.id.pic);
        Cursor c = h.getprofile(db);
        expText = (EditText) findViewById(R.id.eT);

        Intent i = getIntent();
        final String st = i.getStringExtra("e");
        em = st;

        if(c.moveToFirst())
        {
            do {

                if(c.getString(1).equals(st))
                {
                    profileArray[0] = "Name: "+c.getString(0);
                    TextView t =  (TextView)findViewById(R.id.name);
                    t.append(c.getString(0));
                    profileArray[1]= "Email: "+c.getString(1);
                    profileArray[2]="Division: "+c.getString(2);
                    profileArray[3] = "Zilla: "+c.getString(3);
                    profileArray[4]="Address: "+c.getString(4);
                    profileArray[5]= "Phone: "+c.getString(5);
                    profileArray[6]= "Experience: "+c.getString(6);
                    ppic = c.getString(7);

                    if(!TextUtils.isEmpty(ppic))
                    {
                        byte[] decodedString = Base64.decode(ppic, Base64.DEFAULT);
                        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                        imageView.setImageBitmap(decodedByte);

                    }

                    this.pid = c.getInt(8);

                    break;
                }

            }while (c.moveToNext());
        }
        c.close();
        a = new ArrayAdapter<String>(this,R.layout.listview, profileArray);
        lp.setAdapter(a);

    }
    public  void  editbutton(View v)
    {
        String login=sharedPreferences.getString("login","");
        if(login.equalsIgnoreCase("0"))
        {
            Toast.makeText(this, "Your are not logged in", Toast.LENGTH_SHORT).show();
           Intent i = new Intent(this,MainActivity.class );
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i); finish();
        }
        if (p != null)
            showPopup(show_profile.this, p);


    }
    public void onWindowFocusChanged(boolean hasFocus) {

        int[] location = new int[2];
        Button button = (Button) findViewById(R.id.button);
        // Get the x, y location and store it in the location[] array
        // location[0] = x, location[1] = y.
        button.getLocationOnScreen(location);
        //Initialize the Point with x, and y positions
        p = new Point();
        p.x = location[0];
        p.y = location[1];
    }

    // The method that displays the popup.
    private void showPopup(final Activity context, Point p) {
        int popupWidth = 600;
        int popupHeight = 800;

        // Inflate the popup_layout.xml
        LinearLayout viewGroup = (LinearLayout) context.findViewById(R.id.popup);
        LayoutInflater layoutInflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = layoutInflater.inflate(R.layout.activity_edit_profile, viewGroup);

        // Creating the PopupWindow
         popup = new PopupWindow(context);
        popup.setContentView(layout);
        popup.setWidth(popupWidth);
        popup.setHeight(popupHeight);
        popup.setFocusable(true);
  // Some offset to align the popup a bit to the right, and a bit down, relative to button's position.
        int OFFSET_X = 30;
        int OFFSET_Y = 30;

        // Displaying the popup at the specified location, + offsets.
        popup.showAtLocation(layout, Gravity.NO_GRAVITY, p.x + OFFSET_X, p.y + OFFSET_Y);

        // Getting a reference to Close button, and close the popup when clicked.
        Button close = (Button) layout.findViewById(R.id.addpic);
        Button b1 = (Button) layout.findViewById(R.id.change);
        expText = (EditText) layout.findViewById(R.id.eT);
        adText = (EditText)layout.findViewById(R.id.aT);
        phoneText = (EditText)layout.findViewById(R.id.pT);
        passText = (EditText)layout.findViewById(R.id.passT);
        b1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor c = h.getprofile(db);
                final String table1= "profile1";

                if(c.moveToFirst())
                {

                    do {
                        Log.i("nabila", c.getString(1)+" "+em +" "+ c.getInt(8)+" "+pid);
                        if(c.getString(1).equals(em) && c.getInt(8) == pid)
                        {

                            if(expText.getText().toString().length()>1)
                            {
                                String exp = expText.getText().toString();
                                ContentValues val = new ContentValues();
                                val.put("experience",exp);
                                db.update(table1,val,"id = "+pid,null);
                            }
                            if(passText.getText().toString().length()>1)
                            {
                                String pass = passText.getText().toString();
                                ContentValues val = new ContentValues();
                                val.put("password",pass);
                                db.update(table1,val,"id = "+pid,null);
                            }
                            if(adText.getText().toString().length()>1)
                            {
                                String s = adText.getText().toString();
                                ContentValues val = new ContentValues();
                                val.put("adress",s);
                                db.update(table1,val,"id = "+pid,null);
                            }
                            if(phoneText.getText().toString().length()>1)
                            {
                                String s = phoneText.getText().toString();
                                ContentValues val = new ContentValues();
                                val.put("phone",s);
                                db.update(table1,val,"id = "+pid,null);
                            }

                           break;
                        }

                    }while (c.moveToNext());
                }
                else Log.i("nabila", "dgjkd");
                c.close();
               popup.dismiss();
                Intent intent = getIntent();
                finish();
                startActivity(intent);
            }
        });

        close.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, SELECT_PHOTO);



            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);

        switch (requestCode) {
            case SELECT_PHOTO:
                if (resultCode == RESULT_OK) {
                    try {
                        final Uri imageUri = imageReturnedIntent.getData();
                        final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                        final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);

                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        selectedImage.compress(Bitmap.CompressFormat.PNG, 100, bos);


                        if (selectedImage.getByteCount() < 1500000) {
                            byte[] img = bos.toByteArray();

                            String encodedImage = Base64.encodeToString(img, Base64.DEFAULT);
                            ppic = encodedImage;

                            Cursor c = h.getprofile(db);
                            final String table1 = "profile1";
                            if (c.moveToFirst()) {
                                do {
                                    if (c.getString(1).equals(em)) {
                                        //  expText = (EditText) findViewById(R.id.eT);
                                       // String exp = expText.getText().toString();
                                        ContentValues val = new ContentValues();
                                        val.put("pic", ppic);
                                        db.update(table1, val, "id = "+pid, null);


                                        break;
                                    }

                                } while (c.moveToNext());


                                byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
                                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                                imageView.setImageBitmap(decodedByte);
                                popup.dismiss();

                            } else

                                Toast.makeText(show_profile.this,
                                        "Please select a profile picture less than 3500000 byte", Toast.LENGTH_LONG).show();



                        }
                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    }

                }
        }
    }

    public void logout(View view)
    {
        //session.logoutUser();
        // finish();
        editor.putString("login","0");
        editor.commit();

        Intent intent=new Intent(show_profile.this,MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();

    }

 /*   @Override
    protected void onStop() {
        super.onStop();
       //finish();

    }
    public boolean onKeyDown(int keycode, KeyEvent event) {
        if (keycode == KeyEvent.KEYCODE_BACK) {
            Intent intent=new Intent(show_profile.this,home.class);
            startActivity(intent);
        }

        return super.onKeyDown(keycode, event);
    }*/

}
