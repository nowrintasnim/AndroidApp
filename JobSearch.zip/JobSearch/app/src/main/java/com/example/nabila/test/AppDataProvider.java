package com.example.nabila.test;

/**
 * Created by Nabila on 12/28/2016.
 */
public class AppDataProvider {

    int app_id, pro_id,job_id, granted;
    String  Ap_add_col, Ap_exp_col,expert_col, more_col,prof_col, jobname, appname;

    public AppDataProvider()
    {

    }

    public void setApp_id(int i)
    { this.app_id = i; }
    public int getApp_id()
    { return  this.app_id ; }

    public void setGranted(int granted) {
        this.granted = granted;
    }

    public int getGranted() {
        return granted;
    }

    public int getPro_id() {
        return pro_id;
    }

    public void setPro_id(int pro_id) {
        this.pro_id = pro_id;
    }

    public void setJob_id(int job_id) {
        this.job_id = job_id;
    }

    public int getJob_id() {
        return job_id;
    }

    public void setAp_add_col(String ap_add_col) {
        Ap_add_col = ap_add_col;
    }

    public String getAp_add_col() {
        return Ap_add_col;
    }

    public void setAp_exp_col(String ap_exp_col) {
        Ap_exp_col = ap_exp_col;
    }

    public String getAp_exp_col() {
        return Ap_exp_col;
    }

    public void setProf_col(String prof_col) {
        this.prof_col = prof_col;
    }

    public String getProf_col() {
        return prof_col;
    }

    public void setExpert_col(String expert_col) {
        this.expert_col = expert_col;
    }

    public String getExpert_col() {
        return expert_col;
    }

    public void setMore_col(String more_col) {
        this.more_col = more_col;
    }

    public String getMore_col() {
        return more_col;
    }

    public void setJobname(String jobname) {
        this.jobname = jobname;
    }

    public String getJobname() {
        return jobname;
    }

    public void setappname(String appname) {
        this.appname = appname;
    }

    public String getappname() {
        return appname;
    }

}

