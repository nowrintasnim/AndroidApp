package com.example.nabila.test;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nabila on 1/10/2017.
 */
public class Adaptor_for_showapplicant extends ArrayAdapter {
    List Joblist = new ArrayList();
    JobDataProvider ob;
    Context context;

    public Adaptor_for_showapplicant(Context context, int resource)
    {
        super(context, resource);
        this.context = context;
    }


    public void add(Object object)
    {
        super.add(object);
        Joblist.add(object);
    }
  /*  @Override
    public  int jobListCount()
    {
        return Joblist.size();
    }*/

    @Override
    public Object getItem(int position) {
        return Joblist.get(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View  row = convertView;
        LayoutHandler h;
        if(row ==  null)
        {
            LayoutInflater inflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.listview,parent,false);
            h = new LayoutHandler();
            h.jobname = (TextView)row.findViewById(R.id.label);
//            h.grntCheck = (CheckBox)row.findViewById(R.id.checkBox_list);

            row.setTag(h);

        }
        else
        {
            h =  (LayoutHandler)row.getTag();
        }

        ob = (JobDataProvider)this.getItem(position);
        h.jobname.setText(ob.getJobname() );
        return row ;
    }

    static class LayoutHandler
    {
        TextView jobname;
        CheckBox grntCheck;
    }
}
