package com.example.nabila.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MyApplications extends AppCompatActivity {

    String[] apArray = new String[5];

    ArrayAdapter<String> a;
    ListView lp;
    DbHelper h;
    SQLiteDatabase db;
    int pid;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_applications);
        preferences= PreferenceManager.getDefaultSharedPreferences(MyApplications.this);
        editor=preferences.edit();

        h= new DbHelper(this);
        db = h.getReadableDatabase();
        //applicantAdaptor appAdaptor = new applicantAdaptor(getApplicationContext(),R.layout.listview);
        applicantAdaptor appAdaptor = new applicantAdaptor(getApplicationContext(),R.layout.gridrow);
        lp = (ListView)findViewById(R.id.myapplication_list);

        Intent i = getIntent();
        final int pp = i.getIntExtra("pid",-1);
        final int jobid = i.getIntExtra("jobid", -1);
        final String jobname = i.getStringExtra("jobname");
        TextView t = (TextView)findViewById(R.id.my_ap_text);

        pid = pp;
        Boolean bool = false;

        Cursor c = h.getapplicant(db);

        if(c.moveToFirst())
        {
            do{
                if(c.getInt(0) == pid)
                {
                    AppDataProvider ob = new AppDataProvider();
                    int job_id = c.getInt(6);
                    ob.setGranted(c.getInt(8));

                    Cursor c1 = h.getJobForList(db);
                    if(c1.moveToFirst())
                    {
                        do {
                            if(c1.getInt(0) == job_id )
                            {
                                ob.setappname(c1.getString(1));
                                bool = true;
                                break;
                            }
                        }while (c1.moveToNext());
                    }
                    c1.close();
                    appAdaptor.add(ob);
                    bool = true;
                }

            }while(c.moveToNext());

        }
        if(!bool) t.setText("You have not applied for any job");

        lp.setAdapter(appAdaptor);
        c.close();

    }
    public void logout(View view)
    {
        editor.putString("login","0");
        editor.commit();
        Intent intent=new Intent(MyApplications.this,MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();

    }
}
