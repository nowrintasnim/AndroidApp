package com.example.nabila.test;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

public class home extends AppCompatActivity {


    String em, name, jobname, empname,st ;
    int grant, jobid, empid,pp;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    String login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        final get_P_id p = new get_P_id();
        DbHelper h = new DbHelper(this);
        preferences= PreferenceManager.getDefaultSharedPreferences(home.this);
        editor=preferences.edit();


        TextView id_pr = (TextView) findViewById(R.id.id_pr);
        TextView id_app = (TextView) findViewById(R.id.id_applicant);
        TextView id_show = (TextView) findViewById(R.id.id_show);
        TextView id_up = (TextView) findViewById(R.id.id_up);
        TextView id_my_job = (TextView)findViewById(R.id.id_show_myjob);
        TextView id_myapply = (TextView)findViewById(R.id.id_my_application);

        assert id_app != null;
        assert id_pr != null;
        assert id_show != null;
        assert id_up != null;
        assert  id_my_job != null;
        assert  id_myapply != null;
        final Context c = this;

        String id=preferences.getString("id","");
        Intent i = getIntent();
       /* pp = i.getIntExtra("pid", -1);
        name = i.getStringExtra("n");
        st = i.getStringExtra("e");*/
        pp = Integer.parseInt(id);
        name = preferences.getString("name","" );
        st = preferences.getString("email", "");

        id_my_job.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                login=preferences.getString("login","");
                if(login.equalsIgnoreCase("0"))
                {
                    Intent i = new Intent(home.this,MainActivity.class );
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                    Toast.makeText(home.this, "Your are not logged in", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                Intent i = new Intent(home.this, show_my_job.class);
                i.putExtra("pid", pp);
                home.this.startActivity(i);
            }
        });
        id_pr.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                login=preferences.getString("login","");
                if(login.equalsIgnoreCase("0"))
                {
                    Intent i = new Intent(home.this,MainActivity.class );
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                    Toast.makeText(home.this, "Your are not logged in", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                Intent showpr = new Intent(home.this, show_profile.class);
                showpr.putExtra("e", st);
                home.this.startActivity(showpr);
            }
        });
        id_up.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                login=preferences.getString("login","");
                if(login.equalsIgnoreCase("0"))
                {
                    Intent i = new Intent(home.this,MainActivity.class );
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                    Toast.makeText(home.this, "Your are not logged in", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                Intent upjob = new Intent(home.this, up_job.class);
                upjob.putExtra("pid", pp);
                upjob.putExtra("e", st );
                upjob.putExtra("n", name);
                home.this.startActivity(upjob);
            }
        });
        id_app.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                login=preferences.getString("login","");
                if(login.equalsIgnoreCase("0"))
                {
                    Intent i = new Intent(home.this,MainActivity.class );
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                    Toast.makeText(home.this, "Your are not logged in", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                Intent a = new Intent(home.this, show_applicant_3.class);
                a.putExtra("pid", pp);
                home.this.startActivity(a);
            }
        });
        id_show.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                login=preferences.getString("login","");
                if(login.equalsIgnoreCase("0"))
                {
                    Log.i("nabila", "log out");
                    Intent i = new Intent(home.this,MainActivity.class );
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                    Toast.makeText(home.this, "Your are not logged in", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                Intent showj = new Intent(home.this, showjob.class);
                showj.putExtra("pid", pp);
                home.this.startActivity(showj);
            }
        });
        id_myapply.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                login=preferences.getString("login","");
                if(login.equalsIgnoreCase("0"))
                {
                    Intent i = new Intent(home.this,MainActivity.class );
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                    Toast.makeText(home.this, "Your are not logged in", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                Intent showj = new Intent(home.this, MyApplications.class);
                showj.putExtra("pid", pp);
                home.this.startActivity(showj);
            }
        });


        SQLiteDatabase db = h.getReadableDatabase();
      /*  NotificationManager n = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Cursor cs = h.getapplicant(db);
        int cnt = 0;
        if (cs.moveToFirst()) {
            do {
                if (cs.getInt(0) == pp) {
                    jobid = cs.getInt(6);
                    empid = cs.getInt(7);
                    Cursor c1 = h.getJobForList(db);
                    if (c1.moveToFirst()) {
                        do {
                            if (c1.getInt(0) == jobid) {
                                jobname = c1.getString(1);
                                break;
                            }
                        } while (c1.moveToNext());
                    }
                    Cursor c2 = h.getprofile(db);
                    if (c2.moveToFirst()) {
                        do {
                            if (c2.getInt(8) == empid) {
                                empname = c2.getString(0);
                                em = c2.getString(1);
                                break;
                            }
                        } while (c2.moveToNext());
                    }

                    Notification notify = new Notification.Builder(c).setSmallIcon(R.drawable.back).
                            setContentTitle("Granted").setContentText(name + "You have granted for " + jobname + ".\nPlease contact with " + empname).build();
                    n.notify(cnt++, notify);
                }
            } while (cs.moveToNext());
        }*/

        Cursor c1 = h.getJobForList(db);
        if (c1.moveToFirst()) {
            do {
               Log.i("nabila", "job id = "+ c1.getInt(0) +" emp id = " + c1.getInt(8));

            } while (c1.moveToNext());
        }
        Cursor c2 = h.getprofile(db);
        if (c2.moveToFirst()) {
            do {
                Log.i("nabila", "job id = "+ c2.getInt(8));

            } while (c2.moveToNext());
        }
        c1.close();c2.close();

    }


        public void logout(View view)
        {
            editor.putString("login","0");
            editor.commit();
            Intent intent=new Intent(home.this,MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();

        }

    public boolean onKeyDown(int keycode, KeyEvent event) {
        if (keycode == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(false);
            finish();
        }

        return super.onKeyDown(keycode, event);
    }
/*
    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }*/

}



