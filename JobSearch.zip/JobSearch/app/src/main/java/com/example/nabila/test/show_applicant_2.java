package com.example.nabila.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class show_applicant_2 extends AppCompatActivity {

    String[] apArray = new String[5];

    ArrayAdapter<String> a;
    ListView lp;
    DbHelper h;
    SQLiteDatabase db;
    int pid;
    String em;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_applicant_2);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(show_applicant_2.this);
        editor=sharedPreferences.edit();

        h= new DbHelper(this);
        db = h.getReadableDatabase();

        applicantAdaptor appAdaptor = new applicantAdaptor(getApplicationContext(),R.layout.gridrow);
        lp = (ListView)findViewById(R.id.apView2);
        t = (TextView)findViewById(R.id.textView5);

        Intent i = getIntent();
        final int pp = i.getIntExtra("pid",-1);
        final int jobid = i.getIntExtra("jobid", -1);
        final String jobname = i.getStringExtra("jobname");
        t.setText("Applicants for "+jobname);
        pid = pp;
        Boolean bool = false;

        Cursor c = h.getapplicant(db);

        if(c.moveToFirst())
        {
            do{
              //  Log.i("nabila", " in shoap2 "+c.getString(3));
                if(jobid == c.getInt(6) &&c.getInt(7) == pid)
                {
                    AppDataProvider ob = new AppDataProvider();
                    int app_id = c.getInt(0);
                 //   Log.i("nabila", "app id = "+app_id +"  job id "+job_id);
                    ob.setPro_id(pid);
                    ob.setJob_id(jobid);
                    ob.setApp_id(app_id);
                    ob.setJobname(jobname);
                    ob.setAp_add_col(c.getString(1));
                    ob.setAp_exp_col(c.getString(2));
                    ob.setExpert_col(c.getString(3));
                    ob.setMore_col(c.getString(4));
                    ob.setProf_col(c.getString(5));
                    ob.setGranted(c.getInt(8));
                //    Log.i("nabila", "g = "+ob.getGranted());
                    Cursor c1 = h.getprofile(db);
                    if(c1.moveToFirst())
                    {
                        do {
                            if(c1.getInt(8) == app_id )
                            {
                                ob.setappname(c1.getString(0));
                                break;
                            }
                        }while (c1.moveToNext());
                    }
                    c1.close();
                    appAdaptor.add(ob);
                    bool = true;
                }

            }while(c.moveToNext());

        }

        if(!bool) Toast.makeText(this, "No  one applied for this job",Toast.LENGTH_SHORT).show();
        else lp.setAdapter(appAdaptor);
        c.close();



        lp.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // When clicked, show a toast with the TextView text
                String login=sharedPreferences.getString("login","");
                if(login.equalsIgnoreCase("0"))
                {
                    Intent i = new Intent(show_applicant_2.this,MainActivity.class );
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i); finish();
                    Toast.makeText(show_applicant_2.this, "You are not logged in!", Toast.LENGTH_SHORT).show();
                    finish();return;
                }
               AppDataProvider ob = (AppDataProvider) parent.getItemAtPosition(position);
                Intent a = new Intent(show_applicant_2.this, applicant_details.class);
                a.putExtra("jobname",ob.getJobname());
                a.putExtra("appname", ob.getappname());
                a.putExtra("exp", ob.getAp_exp_col());
                a.putExtra("expert", ob.getExpert_col());
                a.putExtra("more", ob.getMore_col());
                a.putExtra("prof", ob.getProf_col());
                a.putExtra("add",ob.getAp_add_col());
                //  Log.i("nabila", "job id in showjob "+ob.getJobidId());
                a.putExtra("pro",ob.getPro_id());
                a.putExtra("jobid", ob.getJob_id());
                a.putExtra("appid",ob.getApp_id());
                show_applicant_2.this.startActivity(a);
                // Toast.makeText(getApplicationContext(), "Clicked on Row: " + ob.getJobname(), Toast.LENGTH_LONG).show();
            }
        });


    }
    public void logout(View view)
    {
        //session.logoutUser();
        // finish();
        editor.putString("login","0");
        editor.commit();

        Intent intent=new Intent(show_applicant_2.this,MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

}
