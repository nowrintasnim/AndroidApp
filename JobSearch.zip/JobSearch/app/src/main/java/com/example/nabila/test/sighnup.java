package com.example.nabila.test;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

public class sighnup extends AppCompatActivity {

    DbHelper helper = new DbHelper(this);
    SQLiteDatabase d ;
    Context context = this;
    LinearLayout viewgroup;
    EditText nameText;
    EditText adText;
    EditText emailText;
    EditText phoneText ;
    EditText zilaText ;
    EditText divText ;
    EditText passText;
    EditText passText2;
    Spinner divT;
    final String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    Spinner sp;
    ArrayAdapter<String> adapter;
    String [] ar= {"Select Division","Dhaka","Khulna","Slyhet", "Chittagong", "Barishal", "Rajshahi","Rangpur", "Mymenshing"};


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sighnup);

        sp = (Spinner)findViewById(R.id.spinner_in_signup);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ar);
        adapter.setDropDownViewResource(android.R.layout.simple_selectable_list_item);
        // sp.setBackgroundResource(R.drawable.spinner_img);
        sp.setAdapter(adapter);
        sp.setSelection(0);

        nameText = (EditText) findViewById(R.id.nameText);
        adText = (EditText) findViewById(R.id.adText);
        emailText = (EditText) findViewById(R.id.loginEmail);
        phoneText = (EditText) findViewById(R.id.phoneText);
        zilaText = (EditText) findViewById(R.id.zilaText);
      //  divText = (EditText) findViewById(R.id.divText);
        passText = (EditText) findViewById(R.id.passText);
        passText2 = (EditText) findViewById(R.id.passText2);
        divT = (Spinner)findViewById(R.id.spinner_in_signup);
        // Button sumbitbutton =(Button)findViewById(R.id.submitbutton);

    }

    public void onSignupClick(View view) {
        viewgroup = (LinearLayout)findViewById(R.id.ln);
        if(view.getId() == R.id.submitbutton)
        {
            if(checkFieldsRequired(viewgroup)) {

                String stname = nameText.getText().toString();
                String staddress = adText.getText().toString();
             //   String stdiv = divText.getText().toString();
                String stzila = zilaText.getText().toString();
                String stphone = phoneText.getText().toString();
                String stpass = passText.getText().toString();
                String stemail = emailText.getText().toString();
                String stpass2 = passText2.getText().toString();
                String stdiv ;

                final  String em= emailText.getText().toString().trim();

                if(stphone.toString().length()<= 10) {
                    Toast.makeText(context, "invalid phone number!", Toast.LENGTH_LONG).show();
                    return;
                }
                if(!stpass.equals(stpass2))
                {
                    Log.i("nabila", stpass +"  "+ stpass2);
                    Toast.makeText(sighnup.this, "Password should be same in both field", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(divT.getSelectedItemPosition()>0)
                {
                    stdiv = divT.getSelectedItem().toString();
                     Log.i("nabila", stdiv);
                    //return;
                }
                else {
                    Toast.makeText(sighnup.this, "Select Division!", Toast.LENGTH_SHORT).show();
                    return;
                }

                SQLiteDatabase db;
                db = helper.getReadableDatabase();
                Cursor cs = helper.getprofile(db);
                boolean f=false;
                if(cs.moveToFirst())
                {
                    do {
                        if(cs.getString(1).equals(stemail))
                        {
                            f=true;
                            break;
                        }

                    }while (cs.moveToNext());
                }
                cs.close();
                db.close();
                if(!f )
                {
                    if( em.matches(emailPattern))
                    {
                        contact c = new contact();
                        c.setAdress(staddress);
                        c.setDivision(stdiv);
                        c.setEmail(stemail);
                        c.setName(stname);
                        c.setPass(stpass);
                        c.setPhone(stphone);
                        c.setZila(stzila);
                        d = helper.getWritableDatabase();
                       //
                        helper.insertContact(c, d);
                        Intent i = new Intent(this, MainActivity.class);
                        d.close();
                        adText.setText("");zilaText.setText("");emailText.setText("");nameText.setText("");
                        passText.setText("");phoneText.setText("");
                        passText2.setText("");
                        sp.setSelection(0);
                        startActivity(i);

                    }
                    else
                    {
                        Toast.makeText(context, "invalid email id. give a valid email !", Toast.LENGTH_LONG).show();
                    }

                }
                else
                {
                    Toast.makeText(context, "Already Exists!", Toast.LENGTH_LONG).show();

                }

            }


        }

    }

    public boolean checkFieldsRequired(ViewGroup viewGroup){

        int count = viewGroup.getChildCount();
        for (int i = 0; i < count; i++) {
            View view = viewGroup.getChildAt(i);

            if (view instanceof EditText) {
                EditText edittext = (EditText) view;

                if (edittext.getText().toString().trim().equals("") )
                {
                    edittext.setError("Required!");
                    return false;
                }
            }
        }
        return true;

    }
}

