package com.example.nabila.test;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Toast;


/**
 * Created by Nabila on 12/8/2016.
 */
public class JobListAdaptor extends ArrayAdapter {

    List Joblist = new ArrayList();
    JobDataProvider ob;
    Context context;

    public JobListAdaptor(Context context, int resource)
    {
        super(context, resource);
        this.context = context;
    }


    public void add(Object object)
    {
       super.add(object);
        Joblist.add(object);
    }
  /*  @Override
    public  int jobListCount()
    {
        return Joblist.size();
    }*/

    @Override
    public Object getItem(int position) {
        return Joblist.get(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View  row = convertView;
        LayoutHandler h;
        if(row ==  null)
        {
            LayoutInflater inflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.gridrow,parent,false);
            h = new LayoutHandler();
            h.jobname = (TextView)row.findViewById(R.id.jobname_list);
            h.grntCheck = (CheckBox)row.findViewById(R.id.checkBox_list);

            row.setTag(h);

        }
        else
        {
            h =  (LayoutHandler)row.getTag();
        }

        ob = (JobDataProvider)this.getItem(position);
        h.jobname.setText(ob.getJobname() );
        h.grntCheck.setChecked(ob.getGrant() );



        return row ;
    }

    static class LayoutHandler
    {
        TextView jobname;
        CheckBox grntCheck;
    }
}
