package com.example.nabila.test;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class applicant_details extends AppCompatActivity {

    String[] appdetails = new String[6];

    ArrayAdapter<String> a;
    SQLiteDatabase db;
    DbHelper h;
    ListView lp;
    int ji, ai,pi;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.applicant_details);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicant_details.this);
        editor=sharedPreferences.edit();

        lp = (ListView) findViewById(R.id.appDetailsList);
        Intent i = getIntent();
        h = new DbHelper(this);
        db = h.getWritableDatabase();
        appdetails[0] = "Job name: "+i.getStringExtra("jobname");
        appdetails[1] = "Applicant name: "+i.getStringExtra("appname");
        appdetails[2] = "Address: "+i.getStringExtra("add");
        appdetails[3] = "Experience: "+i.getStringExtra("exp");
        appdetails[4] ="Skilled in: "+ i.getStringExtra("expert");
        appdetails[5] = "Profession: "+i.getStringExtra("prof");
        //appdetails[6]= i.getStringExtra("jobname");
        ji = i.getIntExtra("jobid", -1);
        ai = i.getIntExtra("appid", -1);
        pi = i.getIntExtra("pro", -1);
        a = new ArrayAdapter<String>(this, R.layout.listview, appdetails);
        lp.setAdapter(a);
    }


    public void grantButtonClick(View view)
    {
        String login=sharedPreferences.getString("login","");
        if(login.equalsIgnoreCase("0"))
        {
            Intent i = new Intent(applicant_details.this,MainActivity.class );
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i); finish();
            Toast.makeText(applicant_details.this, "You are not logged in!", Toast.LENGTH_SHORT).show();
            finish();return;
        }

        Cursor c =  h.getJobForList(db);
        boolean g =  false;
        if(c.moveToFirst())
        {
            do {
                if(c.getInt(7) == 0 && c.getInt(0) == ji)
                {
                    Log.i("nabila", "job id = "+c.getInt(0));
                    Log.i("nabila","granted = "+c.getInt(7));
                    ContentValues val = new ContentValues();
                    ContentValues val1 = new ContentValues();
                    final String table2 = "Job1";
                    final  String table3 = "Applicant1";
                    val.put("granted", 1);
                    val1.put("app_granted ",1);
                    db.update(table2, val, "jobid = "+ji, null);
                    db.update(table3, val1, ("job_id = "+ji +" and applicant_id = "+ ai+ " and provider_id = "+ pi), null);
                    Toast.makeText(applicant_details.this, "Applicant granted", Toast.LENGTH_SHORT).show();
                    g = true;
                    break;
                }

            }while (c.moveToNext());
        }
        c.close();
        if(g == false)
        {
            Toast.makeText(applicant_details.this, "Already granted applicant for this job", Toast.LENGTH_SHORT).show();
        }

    }
    public void logout(View view)
    {
        editor.putString("login","0");
        editor.commit();
        Intent i=new Intent(this,MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();

    }
}
