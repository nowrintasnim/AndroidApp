package com.example.nabila.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class show_applicant_3 extends AppCompatActivity {

    ArrayAdapter<String> a;
    ListView lp;
    DbHelper h;
    SQLiteDatabase db;
    ListView joblistView;
    int pid;
    String em;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_applicant_3);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(show_applicant_3.this);
        editor=sharedPreferences.edit();

        h =  new DbHelper(this);
        joblistView = (ListView) findViewById(R.id.show_app_list);
        Adaptor_for_showapplicant jobAdaptor = new Adaptor_for_showapplicant(getApplicationContext(),R.layout.listview);

        Intent i = getIntent();
        int pp = i.getIntExtra("pid",-1);
        pid = pp;

        db = h.getReadableDatabase();
        Cursor c = h.getJobForList(db);

        if(c.moveToFirst())
        {
            do {

                String s1;
                int id,grnt;
                id =c.getInt(0);
                s1=c.getString(1);
                grnt=c.getInt(7);
                int provider_id = c.getInt(8);

                Cursor cs = h.getapplicant(db);
                Boolean b = false;
                if(cs.moveToFirst())
                {do{
                    if( c.getInt(0)== cs.getInt(6))
                    {b=true;}
                }while (cs.moveToNext());}

                cs.close();
                if(provider_id == pid && b)
                {
                    JobDataProvider ob =  new JobDataProvider();
                    ob.setJobname(s1);
                    ob.setAddress(c.getString(2));
                    ob.setDate(c.getString(3));
                    ob.setTime(c.getString(4));
                    ob.setCategory(c.getString(5));
                    ob.setPayment(c.getString(6));
                    ob.setJobId(c.getInt(0));
                    //   Log.i("nabila", "job id in showjob "+c.getInt(0));

                    ob.setEmp_id(c.getInt(8));
                    if(c.getInt(7) == 1)
                        ob.setGrant(true);
                    else ob.setGrant(false);
                    jobAdaptor.add(ob);
                }

            }while (c.moveToNext());
        }
        c.close();

        joblistView.setAdapter(jobAdaptor);

        joblistView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // When clicked, show a toast with the TextView text
                String login=sharedPreferences.getString("login","");
                if(login.equalsIgnoreCase("0"))
                {
                    Intent i = new Intent(show_applicant_3.this,MainActivity.class );
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i); finish();
                    Toast.makeText(show_applicant_3.this, "You are not logged in!", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                JobDataProvider ob = (JobDataProvider) parent.getItemAtPosition(position);


                Intent a = new Intent(show_applicant_3.this, show_applicant_2.class);
                a.putExtra("jobname",ob.getJobname());
                a.putExtra("date", ob.getDate());
                a.putExtra("time", ob.getTime());
                a.putExtra("cat", ob.getCategory());
                a.putExtra("pay", ob.getPayment());
                a.putExtra("add", ob.getAddress());
                a.putExtra("jobid",ob.getJobidId());
                //  Log.i("nabila", "job id in showjob "+ob.getJobidId());
                a.putExtra("empid",ob.getEmp_id());
                a.putExtra("grant", ob.getGrant());
                a.putExtra("pid",pid);
                a.putExtra("g", ob.getGrant());
                show_applicant_3.this.startActivity(a);


            }
        });
    }
    public void logout(View view)
    {
        //session.logoutUser();
        // finish();
        editor.putString("login","0");
        editor.commit();

        Intent i=new Intent(show_applicant_3.this,MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();

    }

/*    @Override
    protected void onStop() {
        super.onStop();
        finish();

    }*/
  /*  public boolean onKeyDown(int keycode, KeyEvent event) {
        if (keycode == KeyEvent.KEYCODE_BACK) {
            String login=sharedPreferences.getString("login","");
            if(login.equalsIgnoreCase("0"))
            {
                Intent i=new Intent(show_applicant_3.this,MainActivity.class);
                startActivity(i);
            }
        }

        return super.onKeyDown(keycode, event);
    }*/

}

