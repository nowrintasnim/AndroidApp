package com.example.nabila.test;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

public class up_job extends AppCompatActivity {

    DbHelper helper = new DbHelper(this);
    SQLiteDatabase d ;
    Context context = this;
    int pid  = -1 ;
    LinearLayout viewgroup;
    EditText jobText;
    EditText adText;
    EditText dateText;
    EditText timeText ;

    Spinner catText;
    EditText payText;

    Spinner sp_time;
    Spinner sp_day;
    Spinner sp_month;
    Spinner sp_year;
    Spinner sp;
    Spinner sp_a;
    SharedPreferences sharedPreferences;
    ArrayAdapter<String> adapter, ad_time, ad, ad_day, ad_year, ad_month;
    String [] ar= {"Select Category","Electrician","Plumbiing","Catering", "House Staff", "Sales", "Volunteer","Others"};
    String [] a= {"Select","am", "pm"};
    String[] time = {"Time","1", "2","3","4","5", "6", "7", "8", "9", "10", "11", "12"};
    String []day = {"Day", "1", "2","3","4","5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
    "22", "23", "24", "26", "27", "28", "29", "30", "31"};
    String[] month = {"Month", "Jan", "Feb", "Mar", "April", "May", "June", "July","Aug", "Sep", "Oct", "Nov", "Dec"};
    String [] year = {"Year", "2017", "2018", "2019", "2020"};
    String name,st;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.up_job);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(up_job.this);

        sp= (Spinner)findViewById(R.id.spinner);
        sp_a = (Spinner)findViewById(R.id.sp);
        sp_time =(Spinner) findViewById(R.id.time_sp);
        sp_day = (Spinner)findViewById(R.id.day_sp);
        sp_month = (Spinner)findViewById(R.id.month_sp);
        sp_year= (Spinner)findViewById(R.id.year_sp);


        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ar);
        adapter.setDropDownViewResource(android.R.layout.simple_selectable_list_item);
        ad_time = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, time);
        ad_time.setDropDownViewResource(android.R.layout.simple_selectable_list_item);
        ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, a);
        ad.setDropDownViewResource(android.R.layout.simple_selectable_list_item);
        ad_day = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, day);
        ad_day.setDropDownViewResource(android.R.layout.simple_selectable_list_item);

        ad_month = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, month);
        ad_month.setDropDownViewResource(android.R.layout.simple_selectable_list_item);
        ad_year = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, year);
        ad_year.setDropDownViewResource(android.R.layout.simple_selectable_list_item);
        // sp.setBackgroundResource(R.drawable.spinner_img);
        sp.setAdapter(adapter);
        sp.setSelection(0);

        sp_a.setAdapter(ad);
        sp_time.setAdapter(ad_time);
        sp_day.setAdapter(ad_day);
        sp_month.setAdapter(ad_month);
        sp_year.setAdapter(ad_year);


        Intent i = getIntent();
        int pp = i.getIntExtra("pid",-1);
        st = i.getStringExtra("e");
        name = i.getStringExtra("n");
        pid =  pp;

        jobText = (EditText)findViewById(R.id.JobNameText);
        adText = (EditText)findViewById(R.id.AddText);
        payText = (EditText)findViewById(R.id.paymentText);
        catText = (Spinner)findViewById(R.id.spinner);

    }

    public void submitJob(View view)
    {
        String login=sharedPreferences.getString("login","");
        if(login.equalsIgnoreCase("0"))
        {
            Intent i = new Intent(this,MainActivity.class );
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i); finish();
            Toast.makeText(this, "Your are not logged in", Toast.LENGTH_SHORT).show();
            return;
        }
        viewgroup = (LinearLayout)findViewById(R.id.jopUploadLayout);
        if(view.getId() == R.id.job_submit)
        {
            if(checkFieldsRequired(viewgroup)) {

                String stjobname = jobText.getText().toString();
                String staddress = adText.getText().toString();
                String stdate;

                String stpay = payText.getText().toString();
                String stcat, sttime;
                String t,s , day, mon, year, date;

                if(catText.getSelectedItemPosition()>0)
                {
                    stcat = catText.getSelectedItem().toString();
                }
                else {
                    Toast.makeText(up_job.this, "Select Category!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(sp_time.getSelectedItemPosition()>0)
                {
                    t = sp_time.getSelectedItem().toString();
                }
                else {
                    Toast.makeText(up_job.this, "Select time!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(sp_a.getSelectedItemPosition()>0)
                {
                    s = sp_a.getSelectedItem().toString();
                }
                else {
                    Toast.makeText(up_job.this, "Select am or pm !", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(sp_day.getSelectedItemPosition()>0)
                {
                    day = sp_day.getSelectedItem().toString();
                }
                else {
                    Toast.makeText(up_job.this, "Select day!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(sp_month.getSelectedItemPosition()>0)
                {
                    mon = sp_month.getSelectedItem().toString();
                }
                else {
                    Toast.makeText(up_job.this, "Select month!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(sp_year.getSelectedItemPosition()>0)
                {
                    year = sp_year.getSelectedItem().toString();
                }
                else {
                    Toast.makeText(up_job.this, "Select year!", Toast.LENGTH_SHORT).show();
                    return;
                }
                sttime = t+ " "+s;
                stpay = stpay +" tk";
                stdate = mon+" "+day+","+year;

                d = helper.getWritableDatabase();
                helper.insertJob(stjobname,staddress,stdate,sttime,stcat,stpay, pid, d);

                d.close();
                jobText.setText(""); adText.setText("");payText.setText("");
                sp.setSelection(0);
                sp_time.setSelection(0);
                sp_a.setSelection(0);
                sp_day.setSelection(0);
                sp_month.setSelection(0); sp_year.setSelection(0);

                Toast.makeText(up_job.this, "Successfully Uploaded!", Toast.LENGTH_SHORT).show();
                Intent upjob = new Intent(up_job.this, home.class);
                up_job.this.startActivity(upjob);
                finish();

            }
        }


    }

    public boolean checkFieldsRequired(ViewGroup viewGroup){

        int count = viewGroup.getChildCount();
        for (int i = 0; i < count; i++) {
            View view = viewGroup.getChildAt(i);

            if (view instanceof EditText) {
                EditText edittext = (EditText) view;

                if (edittext.getText().toString().trim().equals("") )
                {
                    edittext.setError("Required!");
                    return false;
                }
            }
        }
        return true;

    }

/*    @Override
    protected void onStop() {
        super.onStop();
        finish();

    }
    public boolean onKeyDown(int keycode, KeyEvent event) {
        if (keycode == KeyEvent.KEYCODE_BACK) {
            Intent intent=new Intent(up_job.this,home.class);
            startActivity(intent);
        }

        return super.onKeyDown(keycode, event);
    }*/


}
