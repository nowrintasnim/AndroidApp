package com.example.nabila.test;

/**
 * Created by Nabila on 12/8/2016.
 */
public class JobDataProvider {

    int jobid,emp_id;
    boolean grant;
    String jobname,address,category,time, payment;
    String date;
    public JobDataProvider(int i, String a, boolean g)
    {
        this.jobid=i; this.jobname=a; this.grant=g;
    }
    public JobDataProvider()
    {

    }
    public void setPayment(String p)
    {
        this.payment = p;
    }
    public String getPayment()
    {
        return  this.payment;
    }

    public void setJobId(int id)
    {
        this.jobid=id;
    }
    public int getJobidId()
    {
        return this.jobid;
    }

    public void setGrant(boolean g)
    {
        this.grant=g;
    }
    public boolean getGrant()
    {
        return this.grant;
    }

    public void setEmp_id(int ei)
    {
        this.emp_id = ei;
    }
    public int getEmp_id(){return this.emp_id;}

    public void setJobname(String jn){ this.jobname = jn; }
    public String getJobname(){ return this.jobname ;}

    public void setAddress(String ad){ this.address=ad; }
    public String getAddress(){ return this.address ;}

    public void setCategory(String cat){ this.category = cat; }
    public String getCategory(){ return this.category ;}

    public void setTime(String t){ this.time = t; }
    public String getTime(){ return this.time;}

    public void setDate(String d){ this.date=d; }
    public String getDate(){ return this.date ;}

}
