package com.example.nabila.test;

/**
 * Created by Nabila on 11/19/2016.
 */
public class contact {

    int id;
    String name,division, phone, pass, zila, address,email, pic;
    public void setId(int id)
    {
        this.id=id;
    }
    public int getId()
    {
        return this.id;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public String getName(){return this.name;}

    public void setEmail(String email){ this.email = email; }
    public String getEmail(){ return this.email ;}
    public void setPic(String email){ this.pic = pic; }
    public String getPic(){ return this.pic ;}


    public void setDivision(String division){ this.division = division; }
    public String getDivision(){ return this.division ;}

    public void setZila(String zila){ this.zila=zila; }
    public String getZila(){ return this.zila ;}

    public void setAdress(String adress){ this.address=adress; }
    public String getAdress(){ return this.address ;}

    public void setPhone(String phone){ this.phone=phone; }
    public String getPhone(){ return this.phone ;}

    public void setPass(String pass ){ this.pass=pass; }
    public String getPass(){ return this.pass ;}



}




