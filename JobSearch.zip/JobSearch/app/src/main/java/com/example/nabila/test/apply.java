package com.example.nabila.test;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class apply extends AppCompatActivity {


    DbHelper helper = new DbHelper(this);
    SQLiteDatabase d ;
    Context context = this;
    LinearLayout viewgroup;

    EditText adText;
    EditText profText;
    EditText expText;
    EditText expertText ;
    EditText moreText ;
    int pid, pro_id , job_id;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.apply);
        preferences= PreferenceManager.getDefaultSharedPreferences(apply.this);
        editor=preferences.edit();
        adText = (EditText) findViewById(R.id.adText_Ap);
        profText = (EditText) findViewById(R.id.profText_Ap);
        expText = (EditText) findViewById(R.id.expText_Ap);
        expertText = (EditText) findViewById(R.id.expertText_Ap);
        moreText = (EditText) findViewById(R.id.moreText_Ap);

        Intent i = getIntent();
        final int pp = i.getIntExtra("pid",-1);
        pid = pp;
        pro_id = i.getIntExtra("pro_id",-1);
        job_id = i.getIntExtra("jobid", -1);
        Log.i("nabila", "job id in apply "+job_id);
    }


    public void onApplyClick(View view) {

        viewgroup = (LinearLayout)findViewById(R.id.ln3);
        if(view.getId() == R.id.applybutton)
        {
            if(checkFieldsRequired(viewgroup)) {

                String staddress = adText.getText().toString();
                String stexp = expText.getText().toString();
                String stexpert = expertText.getText().toString();
                String stpro = profText.getText().toString();
                String stmore = moreText.getText().toString();
                SQLiteDatabase db = helper.getReadableDatabase();
                Cursor cs = helper.getapplicant(db);
                boolean f=false;
                if(cs.moveToFirst())
                {
                    do {
                        if(cs.getInt(0) == pid && cs.getInt(7)==pro_id && cs.getInt(6)==job_id)
                        {
                            f=true;
                            break;
                        }

                    }while (cs.moveToNext());
                }
                cs.close();

                if(!f)
                {
                    d = helper.getWritableDatabase();
                    helper.insertApplicant(pid, pro_id, staddress,stexp,stexpert, stmore ,stpro,job_id, d);
                    d.close();
                    adText.setText(""); expText.setText("");expertText.setText("");profText.setText("");moreText.setText("");
                    Toast.makeText(context, "You have applied for this job successfully !", Toast.LENGTH_SHORT).show();
                }
                else  Toast.makeText(context, "You have already applied for this job!", Toast.LENGTH_SHORT).show();
                for(int i=0; i<100000; i++);
                Intent i = new Intent(this, home.class);
                this.startActivity(i);

            }


        }


    }
    public boolean checkFieldsRequired(ViewGroup viewGroup){

        int count = viewGroup.getChildCount();
        for (int i = 0; i < count; i++) {
            View view = viewGroup.getChildAt(i);

            if (view instanceof EditText) {
                EditText edittext = (EditText) view;

                if (edittext.getText().toString().trim().equals("")  && edittext != moreText && edittext != expertText )
                {
                    edittext.setError("Required!");
                    return false;
                }
            }
        }
        return true;

    }

    public void logout(View view)
    {
        //  session.logoutUser();
        editor.putString("login","0");
        editor.commit();
        Intent intent=new Intent(apply.this,MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);

        finish();
    }
}
