package com.example.nabila.test;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by Nabila on 12/28/2016.
 */
public class applicantAdaptor extends ArrayAdapter{

    List applist = new ArrayList();
    AppDataProvider ob;
    Context context;

    public applicantAdaptor(Context context, int resource)
    {
        super(context, resource);
        this.context = context;
    }


    public void add(Object object)
    {
        super.add(object);
        applist.add(object);
    }

    public Object getItem(int position) {
        return applist.get(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View  row = convertView;
        LayoutHandler h;
        if(row ==  null)
        {
            LayoutInflater inflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
          /*  row = inflater.inflate(R.layout.listview,parent,false);*/
            h = new LayoutHandler();
        //    h.jobname_app = (TextView)row.findViewById(R.id.jobname_app);
            /*h.app_name = (TextView) row.findViewById(R.id.label);*/
            row = inflater.inflate(R.layout.gridrow,parent,false);
            h = new LayoutHandler();
            h.app_name = (TextView)row.findViewById(R.id.jobname_list);
            h.grntCheck = (CheckBox)row.findViewById(R.id.checkBox_list);

            row.setTag(h);

        }
        else
        {
            h =  (LayoutHandler)row.getTag();
        }

        ob = (AppDataProvider)this.getItem(position);
     //   h.jobname_app.setText(ob.getJobname() );
        /*h.app_name.setText(ob.getappname());*/
        h.app_name.setText(ob.getappname());
        Boolean b;
        if(ob.getGranted() == 1) b = true;
        else b = false;
        h.grntCheck.setChecked(b);

        return row ;
    }

    static class LayoutHandler
    {
        TextView jobname_app;
        TextView app_name;
        CheckBox grntCheck;
    }
}
