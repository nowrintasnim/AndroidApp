package com.example.nabila.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.BoringLayout;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class job_details extends AppCompatActivity {
    String[] jobdetails = new String[6];

    ArrayAdapter<String> a;
    ListView lp;

    int provider_id, pid, jobid;
    Button b;
    Boolean grant;

    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_details);
        b = (Button)findViewById(R.id.apply_job_button);


        preferences= PreferenceManager.getDefaultSharedPreferences(job_details.this);
        editor=preferences.edit();

        Intent i = getIntent();
        jobdetails[0]= "Job Name : " + i.getStringExtra("jobname") ;
        jobdetails[1]= "Date :"+i.getStringExtra("date") ;
        jobdetails[2]="Time : " +i.getStringExtra("time") ;
        jobdetails[3]= "Category : "+i.getStringExtra("cat") ;
        jobdetails[4]= "Payment : "+i.getStringExtra("pay") ;
        jobdetails[5]= "Address : "+i.getStringExtra("add") ;

        provider_id = i.getIntExtra("empid", -1);
       // Log.i("nabila","provider id = "+provider_id);
        pid = i.getIntExtra("pid",-1);
        jobid = i.getIntExtra("jobid", -1);
        grant = i.getBooleanExtra("grant",false);
      //  Log.i("nabila", "grant " +grant);
//        Log.i("nabila", " emp id = "+ provider_id);
  //      Log.i("nabila", "pid = "+ pid);

        lp = (ListView)findViewById(R.id.appDetailsList);

        a = new ArrayAdapter<String>(this,R.layout.listview, jobdetails);
        lp.setAdapter(a);

        if(grant) b.setVisibility(View.INVISIBLE);
        if(pid == provider_id)
            b.setVisibility(View.INVISIBLE);



    }
    public void applyclick(View view)
    {
        String login=preferences.getString("login","");
        if(login.equalsIgnoreCase("0"))
        {
            Intent i = new Intent(this,MainActivity.class );
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i); finish();
            Toast.makeText(this, "You are not logged in!", Toast.LENGTH_SHORT).show();
            return;

        }
        Intent a = new Intent(job_details.this, apply.class);
         a.putExtra("pro_id",provider_id);
        a.putExtra("pid",pid);
        a.putExtra("jobid", jobid);
        job_details.this.startActivity(a);
    }
     public void logout(View view)
     {
       //  session.logoutUser();
         editor.putString("login","0");
         editor.commit();
         Intent intent=new Intent(job_details.this,MainActivity.class);
         intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
         intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
         startActivity(intent);

         finish();
     }
}
