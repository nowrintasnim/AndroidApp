package com.example.nabila.test;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.security.PrivateKey;

/**
 * Created by Nabila on 11/19/2016.
 */
public class DbHelper extends SQLiteOpenHelper {
     private   static final int dbversion = 1;
     private static final String dbname="Project";
    private  static final String table1= "profile1";
    private  static final String table2 = "Job1";
    private static final  String table3 = "Applicant1";


    SQLiteDatabase db;

    private  static final String jobid_col = "jobid";
    private  static final String job_col = "job";
    private  static final String add_col = "address";
    private  static final String date_col = "date";
    private  static final String time_col = "time";
    private  static final String granted_col = "granted";
    private  static final String employerid_col = "employerid";
    private  static final String cat_col = "category";
    private static final String pay_col = "payment";


    String cjob = "CREATE TABLE " + table2 + "("
            + jobid_col + " INTEGER PRIMARY KEY AUTOINCREMENT,"
          //  + jobid_col + " INTEGER PRIMARY KEY,"
            +job_col+" VARCHAR NOT NULL,"
            + add_col + " VARCHAR NOT NULL,"
            + date_col+ " VARCHAR NOT NULL,"
            + time_col+ " VARCHAR NOT NULL,"
            + granted_col + " INTEGER,"
            + pay_col +" VARCHAR NOT NULL,"
            +cat_col + " VARCHAR,"
            +employerid_col +" INTEGER NOT NULL,"+" FOREIGN KEY ("+employerid_col+") REFERENCES  " + table1+"("+id_col+"))";

            //+ employerid_col +" INTEGER NOT NULL,"+" FOREIGN KEY ("+employerid_col+") REFERENCES  " + table1+"("+id_col+"))";

    private  static final String id_col = "id";
    private  static final String name_col = "name";
    private  static final String email_col = "email";
    private  static final String div_col = "division";
    private  static final String zila_col = "zila";
    private  static final String phone_col = "phone";
    private  static final String pass_col = "password";
    private  static final String address_col = "adress";
    private  static final String exp_col = "experience";
    private  static final String pic_col = "pic";

    String create = "CREATE TABLE " + table1 + "("
            + id_col + " INTEGER PRIMARY KEY,"
            + name_col + " VARCHAR NOT NULL,"
            + email_col+ " VARCHAR NOT NULL,"
            + div_col+ " VARCHAR NOT NULL,"
            + zila_col + " VARCHAR NOT NULL,"
            +address_col +" VARCHAR NOT NULL,"
            +pass_col +" VARCHAR NOT NULL,"
            +phone_col + " INTEGER,"
            + exp_col+" VARCHAR," + pic_col + " BLOB)";

    private static final String Ap_add_col = "address";
    private static final String more_col = "more";
    private static final String prof_col = "profession";
    private static final String Ap_exp_col = "experience";
    private static final String expert_col = "expert";
    private static final String Ap_job_id_col = "job_id";
    private static final String Ap_id_col = "applicant_id";
    private static final String provider_id = "provider_id";
    private static final String app_granted  = "app_granted";


    String crAp = "CREATE TABLE " + table3 + "("
            + Ap_id_col + " INTEGER,"
            + Ap_add_col + " VARCHAR,"
            + exp_col+ " VARCHAR,"
            + expert_col+ " VARCHAR,"
            + more_col + " VARCHAR,"
            + prof_col +" VARCHAR,"
            + provider_id + " INTEGER,"
            + app_granted + " INTEGER,"
            + Ap_job_id_col + " INTEGER)";


    public DbHelper(Context context)
    {
        super(context, dbname,null, dbversion);
    }

    public void onCreate(SQLiteDatabase db) {

        db.execSQL(cjob);
        db.execSQL(create);
        db.execSQL(crAp);
        this.db = db;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table"+ table1);
        db.execSQL("drop table"+ table2);
        db.execSQL("drop table"+ table3);
        this.onCreate(db);
    }

    public  void insertContact(contact c, SQLiteDatabase d)
    {
        this.getWritableDatabase();

        ContentValues val = new ContentValues();
        String q = "select * from "+table1;
        Cursor cs = d.rawQuery(q,null);
        int cnt =  cs.getCount();

        val.put(id_col,cnt );
        val.put(name_col, c.getName());
        val.put(address_col, c.getAdress());
        val.put(email_col, c.getEmail());
        val.put(div_col, c.getDivision());
        val.put(zila_col, c.getZila());
        val.put(pass_col, c.getPass());
        val.put(phone_col, c.getPhone());
        val.put(pic_col, c.getPic());
        d.insert(table1, null,val);
        cs.close();

        d.close();
        this.close();
    }



    public Cursor getprofile(SQLiteDatabase db)
    {
        Cursor cursor;
        String [] projection ={name_col, email_col, div_col,zila_col, address_col, phone_col, exp_col, pic_col, id_col};
        cursor = db.query(table1, projection, null, null, null, null, null);
        return  cursor;
    }



    public Boolean searchPass(String s, String p, get_P_id p1)
    {
        db = this.getReadableDatabase();
        boolean f = false;
        Cursor c;
        String [] projection ={ name_col, email_col, pass_col, id_col };
        c = db.query(table1, projection, null, null, null, null, null);

        if(c.moveToFirst())
        {
            do {

                if(c.getString(1).equals(s) && c.getString(2).equals(p))
                {
                    f = true;
                    p1.setPid(c.getInt(3));
                    p1.setName(c.getString(0));
                    break;
                }

            }while(c.moveToNext());
        }
        return f;
    }

    public  void insertJob(String n, String a,String d, String t, String c,String p,int pid, SQLiteDatabase d1)
    {
        this.getWritableDatabase();
        ContentValues val = new ContentValues();
        String q = "select * from "+table2;
        Cursor cs = d1.rawQuery(q,null);
        int cnt =  cs.getCount();
        cs.close();
      //  Log.i("nabila","job id in db "+cnt);
      //  val.put(jobid_col,cnt );
        val.put(job_col,n);
        val.put(add_col, a);
        val.put(date_col, d);
        val.put(time_col,t);
        val.put(cat_col,c);
        val.put(pay_col,p);
        val.put(granted_col,0);
        val.put(employerid_col,pid);
        long rowInserted = d1.insert(table2, null,val);
        if(rowInserted != -1)
            Log.i("nabila", "inseted");
        else
            Log.i("nabila","wrng");
        d1.close();
        this.close();


    }

    public void insertApplicant(int pid,int pro_id, String add, String exp, String expert, String more, String prof,int job_id, SQLiteDatabase d )
    {

        ContentValues val = new ContentValues();
        String q = "select * from "+table3;
        Cursor cs = d.rawQuery(q,null);
        int cnt = cs.getCount();
        // need to change Ap_id_col
       // Log.i("nabila" , "job id in insert applicant "+ job_id);
        val.put(Ap_id_col, pid);
        val.put(provider_id, pro_id);
        val.put(Ap_add_col, add);
        val.put(exp_col,exp);
        val.put(expert_col, expert);
        val.put(more_col, more);
        val.put(prof_col, prof);
        val.put(Ap_job_id_col, job_id);
        val.put(app_granted, 0);

        cs.close();
        long rowInserted = d.insert(table3, null,val);
        if(rowInserted != -1)
            Log.i("nabila", "inseted");
        else
            Log.i("nabila","wrng in tbale 3");
        d.close();
        this.close();

    }

    public Cursor getapplicant(SQLiteDatabase db)
    {
        Cursor cursor;
        String [] projection ={Ap_id_col, Ap_add_col, Ap_exp_col,expert_col, more_col, prof_col, Ap_job_id_col, provider_id, app_granted};
        cursor = db.query(table3, projection, null, null, null, null, null);
        return  cursor;
    }

    public Cursor getJobForList(SQLiteDatabase db)
    {
        Cursor cursor;
        String [] projection ={jobid_col, job_col, add_col, date_col, time_col, cat_col, pay_col, granted_col, employerid_col};
        cursor = db.query(table2, projection, null, null, null, null, null);
        if(cursor.getCount() == 0)
        {
            Log.i("nabila", "in dbhelper 0");
        }
        return  cursor;
    }


  /*  boolean isTableExists(SQLiteDatabase db, String tableName)
    {
        if (tableName == null || db == null || !db.isOpen())
        {
            return false;
        }
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type = ? AND name = ?", new String[] {"table", tableName});
        if (!cursor.moveToFirst())
        {
            cursor.close();
            return false;
        }
        int count = cursor.getInt(0);
        cursor.close();
        return count > 0;
    }*/

}
